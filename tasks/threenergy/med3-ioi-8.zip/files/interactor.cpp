#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    setName("Interactor for 'Permutation Median' problem.");
    registerInteraction(argc, argv);

    int queries = 0, N = inf.readInt();
    cout << N << endl << flush;
    vector<int> vec(N);
    for (int& i : vec) {
        i = inf.readInt();
    }
    cout.flush();

    while (true) {
        string x = ouf.readToken();
        if (x == "?") {
            if (++queries > 7777) {
                quitf(_wa, "Number of queries exceeded.");
            }
            int a = ouf.readInt(1, N)-1, b = ouf.readInt(1, N)-1, c = ouf.readInt(1, N)-1;
            vector<pair<int, int>> p = { {vec[a],a}, {vec[b],b}, {vec[c],c} };
            sort(p.begin(), p.end());
            cout << p[1].second+1 << endl << flush;
        }
        else if (x == "!") {
            int ans = ouf.readInt(1, N);
            if (vec[ans-1] == (N+1)/2) {
                tout << queries << endl << flush;
                quitf(_ok, "Number is guessed.");
            }
            else {
                quitf(_wa, "Wrong Answer: '%d' found.", ans);
            }
        }
        else {
            quitf(_wa, "String '%s' from stdin is incorrect.", compress(x).c_str());
        }
    }
}
