#include "testlib.h"

int main(int argc, char * argv[]) {
	registerTestlibCmd(argc, argv);

	int oufq = ouf.readInt();

	if (oufq > 7777) {
		quitf(_wa, "Limit is 7777, but solution have made %d queries", oufq);
	}

	quitf(_ok, "Number is guessed successfully with %d queries", oufq);
}
